from copy import deepcopy

import yaml

# DEFAULT defines the default params used for training / inference
# the parameters here will be overwritten if a yaml config is specified
DEFAULTS = {
    # default: single gpu, can set to cpu
    "devices": ["cuda:0"],
    # fp16: to use mixed precision training 
    "dtype": "fp16",
    # name of the model
    "model_name": "FCOS",
    # output folder that stores all log files and checkpoints
    "output_folder": None,
    "dataset": {
        "name": "VOC2007",
        # training / testing splits
        "train": "trainval",
        "test": "test",
        # folders that store image files / json annotations (following COCO format)
        "img_folder": None,
        "json_folder": None,
    },
    "loader": {
        "batch_size": 4,
        "num_workers": 4,
    },
    "input": {
        # min / max size of the input image
        # min size: shortest side, scale jitter can be specified using a list
        # max size: longest side (must be multiples of 32 due to padding)
        "img_min_size": [256, 288, 320],
        "img_max_size": 480,
        # mean / std for input normalization
        "img_mean": [0.485, 0.456, 0.406],
        "img_std": [0.229, 0.224, 0.225],
    },
    # network architecture
    "model": {
        # type of backbone network
        "backbone": "resnet18",
        # output features from backbone (also as the input features for FPN)
        "backbone_out_feats": ["layer2", "layer3", "layer4"],
        # if to freeze all batchnorms in the backbone
        # this is needed when training with a small batch size
        "backbone_freeze_bn": True,
        # output feature dimensions (assuming resnet18/34)
        "backbone_out_feats_dims": [128, 256, 512],
        # feature dimension after FPN
        "fpn_feats_dim": 256,
        # feature strides in FPN
        "fpn_strides": [8, 16, 32, 64, 128],
        # number of object categories (excluding background)
        "num_classes": 20,
        # regression range for each pyramid level
        "regression_range": [(0, 64), (64, 128), (128, 256), (256, 512), (512, 1000)],
    },
    "train_cfg": {
        # radius used for center sampling during training
        "center_sampling_radius": 1.5,
        # additional params can be added here
    },
    "test_cfg": {
        # score threshold for postprocessing
        "score_thresh": 0.1,
        # IoU threshold for NMS (postprocessing)
        "nms_thresh": 0.6,
        # maximum number of boxes per image (after NMS)
        "detections_per_img": 100,
        # maximum number of boxes per pyramid level (before NMS)
        "topk_candidates": 1000,
        # additional params can be added here
    },
    # optimizer (for training)
    "opt": {
        # solver
        "type": "SGD",
        # solver params
        "momentum": 0.9,
        "weight_decay": 1e-4,
        "learning_rate": 5e-3,
        # excluding the warmup epochs
        "epochs": 10,
        # if to use linear warmup
        "warmup": True,
        "warmup_epochs": 1,
        # lr scheduler: cosine / multistep
        "schedule_type": "cosine",
        # in #epochs excluding warmup
        "schedule_steps": [],
        "schedule_gamma": 0.1,
    },
}


def _merge(src, dst):
    for k, v in src.items():
        if k in dst:
            if isinstance(v, dict):
                _merge(src[k], dst[k])
        else:
            dst[k] = deepcopy(v)


def load_default_config():
    config = deepcopy(DEFAULTS)
    return config


def _update_config(config):
    config["model"].update(config["input"])
    config["model"]["train_cfg"] = config["train_cfg"]
    config["model"]["test_cfg"] = config["test_cfg"]
    return config


def load_config(config_file, defaults=DEFAULTS):
    with open(config_file, "r") as fd:
        config = yaml.safe_load(fd) or {}
    _merge(defaults, config)
    config = _update_config(config)
    return config
